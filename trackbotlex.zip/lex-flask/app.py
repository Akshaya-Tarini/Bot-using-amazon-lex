from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

from flask import Flask, render_template, redirect, url_for, session, request, jsonify
from authlib.integrations.flask_client import OAuth
import os
import boto3
import json
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))
app.config['SERVER_NAME'] = 'localhost:8000'
app.config['PREFERRED_URL_SCHEME'] = 'http'  
oauth = OAuth(app)

# AWS Lex Configuration
lex_client = boto3.client('lexv2-runtime', region_name='us-east-1')
BOT_ID = 'H6ZAUTRKCO'
BOT_ALIAS_ID = 'TSTALIASID'
LOCALE_ID = 'en_US'

# S3 Configuration
s3 = boto3.client('s3', region_name='us-east-1')
CHAT_BUCKET = 'lex-logistics'  # Change this to your actual S3 bucket name

oauth.register(
  name='oidc',
  client_id='28dckj6eub0in34amentv4k0rt',
  client_secret='1rh4h49jf3lacd05e6erd7226ck9rbm5hvdkb0q06731she6clb2',
  authorize_url='https://us-east-1ceppyoahu.auth.us-east-1.amazoncognito.com/oauth2/authorize',
  access_token_url='https://us-east-1ceppyoahu.auth.us-east-1.amazoncognito.com/oauth2/token',
  userinfo_endpoint='https://us-east-1ceppyoahu.auth.us-east-1.amazoncognito.com/oauth2/userInfo',
  jwks_uri='https://cognito-idp.us-east-1.amazonaws.com/us-east-1_CEpPYOahU/.well-known/jwks.json',
  client_kwargs={
    'scope': 'email openid phone',
    'token_endpoint_auth_method': 'client_secret_post'
  }
)

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    """Homepage"""
    user = session.get('user')
    if user:
        return redirect(url_for('chat_app'))
    return render_template('index.html', user=user)

@app.route('/login')
def login():
    """Initiate Cognito OAuth login"""
    redirect_uri = url_for('authorize', _external=True)
    print(f"=== LOGIN INITIATED ===")
    print(f"Redirect URI: {redirect_uri}")
    print(f"Client ID: {oauth.oidc.client_id}")
    return oauth.oidc.authorize_redirect(redirect_uri)

@app.route('/authorize')
def authorize():
    """Handle OAuth callback from Cognito"""
    try:
        print("=== AUTHORIZE ROUTE CALLED ===")
        
        token = oauth.oidc.authorize_access_token()
        print("Token received successfully")
        
        user = token['userinfo']
        print(f"User info: {user}")

        # Store user info in session
        session['user'] = user
        session['access_token'] = token.get('access_token')
        session['id_token'] = token.get('id_token')
        
        print(f"Stored user in session: {user.get('email', user.get('sub'))}")

        # Redirect to chat application
        return redirect(url_for('chat_app'))
        
    except Exception as e:
        print(f"=== AUTHORIZATION ERROR ===")
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return redirect(url_for('index'))

@app.route('/chat-app')
@login_required
def chat_app():
    """Serve the chat application with authenticated user"""
    user = session.get('user')
    id_token = session.get('id_token')
    access_token = session.get('access_token')
    
    print(f"Rendering chat app for user: {user.get('email', user.get('sub'))}")
    
    # Pass tokens and user info to template
    return render_template('chat_app.html', 
                         user=user, 
                         id_token=id_token,
                         access_token=access_token)

@app.route('/api/get-user-info', methods=['GET'])
@login_required
def get_user_info():
    """Return current user info from session"""
    try:
        user = session.get('user', {})
        
        if not user:
            return jsonify({'error': 'No user in session'}), 401
        
        return jsonify({
            'username': user.get('email') or user.get('cognito:username') or user.get('sub'),
            'email': user.get('email'),
            'sub': user.get('sub')
        })
    except Exception as e:
        print(f"Error in get_user_info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/send-message', methods=['POST'])
@login_required
def send_message():
    """Send message to Lex bot"""
    user = session.get('user')
    
    try:
        data = request.json
        user_message = data.get('message', '')
        user_id = user.get('sub', 'anonymous')

        # Generate session ID
        chat_id = data.get('chatId', f"session-{user_id}-{datetime.now().timestamp()}")

        print(f"Sending message to Lex: {user_message[:50]}...")

        # Call Lex
        response = lex_client.recognize_text(
            botId=BOT_ID,
            botAliasId=BOT_ALIAS_ID,
            localeId=LOCALE_ID,
            sessionId=chat_id,
            text=user_message
        )

        bot_message = ''
        if 'messages' in response:
            bot_message = ' '.join([msg['content'] for msg in response['messages']])

        print(f"Lex response: {bot_message[:50]}...")

        return jsonify({
            'success': True,
            'bot_message': bot_message,
            'session_state': response.get('sessionState', {})
        })

    except Exception as e:
        print(f"Error sending message: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/save-chats', methods=['POST'])
@login_required
def save_chats():
    """Save chats to S3"""
    try:
        user = session.get('user', {})
        user_id = user.get('sub', 'unknown')
        data = request.json
        
        print(f"Saving chats for user: {user_id}")
        
        s3.put_object(
            Bucket=CHAT_BUCKET,
            Key=f'chats/{user_id}.json',
            Body=json.dumps(data),
            ContentType='application/json'
        )
        
        print(f"✅ Chats saved successfully for {user_id}")
        return jsonify({'success': True})
        
    except Exception as e:
        print(f"❌ Error saving chats: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/load-chats', methods=['GET'])
@login_required
def load_chats():
    """Load chats from S3"""
    try:
        user = session.get('user', {})
        user_id = user.get('sub', 'unknown')
        
        print(f"Loading chats for user: {user_id}")
        
        response = s3.get_object(Bucket=CHAT_BUCKET, Key=f'chats/{user_id}.json')
        data = json.loads(response['Body'].read())
        
        print(f"✅ Loaded {len(data.get('chats', {}))} chats for {user_id}")
        return jsonify(data)
        
    except s3.exceptions.NoSuchKey:
        print(f"No existing chats for user: {user_id}")
        return jsonify({'chats': {}})
        
    except Exception as e:
        print(f"❌ Error loading chats: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/logout')
def logout():
    """Logout and clear session"""
    print(f"User logging out: {session.get('user', {}).get('email', 'unknown')}")
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=8000)